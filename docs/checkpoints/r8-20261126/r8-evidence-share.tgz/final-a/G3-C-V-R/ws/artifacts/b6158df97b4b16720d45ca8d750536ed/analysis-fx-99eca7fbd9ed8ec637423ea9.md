# 测试报告分析

任务：b6158df97b4b16720d45ca8d750536ed
授权：attn-2ff170f5bc980550f3a1d13b
输入集合 SHA256：eaa88a91e993082192f6c3c2aa4764653e296e41972570d79b399c4a6176bba0

各来源单独核算；不把重复或不同范围的测试合成通过率。

## primary / r8-A-r2 r2

- 结果 SHA256：96706174e6c2dc60a0cb6a3caca5c63e972d9fa4801b801cbe8f7afe9f60084c
- 原始产物 SHA256：44d52a8ae182d7a186baacee9186f9893af4015e415e2da8c0d45425e68ca11f
- 状态：failed
- total=1 passed=0 failed=1

失败明细：
- CI 回归：失败样本必须被报告为 failed: 故意失败：用于验证“失败时才询问是否分析”&#10;&#10;1 !== 0

## 附录报告 / r8-B-r1 r1

- 结果 SHA256：2535839ee2c73f21877571807a609826f4326ad0391535301f1f7656dad7f934
- 原始产物 SHA256：6da62f964a6dd465a065e8afdc4f3babc0203ea30f1b1db0663259861e762a49
- 状态：succeeded
- total=1 passed=1 failed=0

失败明细：
- 当前报告没有记录失败。

## 判断与下一步

至少一个来源仍有失败：先处理上述失败并重跑对应测试，不把本轮报告作为全通过结果。
