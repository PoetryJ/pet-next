# 测试报告分析

任务：7fc40b642aa642972d6af220de2d878d
授权：attn-3cd4ed08ad3b5f0635e16537
输入集合 SHA256：cf6ed09c70eee2e6c2af8061d8f229b9b75024f4cb7dccef1b72d7d6d101ec4b

各来源单独核算；不把重复或不同范围的测试合成通过率。

## primary / r8-A-r2 r2

- 结果 SHA256：138b956ce4d001949ac358e52d9185ecb3aa103d36d9f78945f19c39b09f1622
- 原始产物 SHA256：fecf0001bf2657323644b2f413e0ddd224936ca376fa307138252414e2156492
- 状态：failed
- total=1 passed=0 failed=1

失败明细：
- CI 回归：失败样本必须被报告为 failed: 故意失败：用于验证“失败时才询问是否分析”&#10;&#10;1 !== 0

## 附录报告 / r8-B-r1 r1

- 结果 SHA256：9aedcab475bdb702a8a2d3dd713cf4acd4c4cc1015b82ee74daeacf83a47c085
- 原始产物 SHA256：74b295f3a027702c0eaa5a6f2ad0d40d8ed61b02c21f4bf10a96141e6ee82158
- 状态：succeeded
- total=1 passed=1 failed=0

失败明细：
- 当前报告没有记录失败。

## 判断与下一步

至少一个来源仍有失败：先处理上述失败并重跑对应测试，不把本轮报告作为全通过结果。
