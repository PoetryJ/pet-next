# 测试报告分析

任务：91efdb9af29c04563184950e8dcb9fbc
授权：attn-9b8151b30c5465632d3beaa5
输入集合 SHA256：7e71e8d693311b7e53bea208181679e60e150d23860ababf55e418297244b51a

各来源单独核算；不把重复或不同范围的测试合成通过率。

## primary / r8-A-r2 r2

- 结果 SHA256：6d880f94244b860c6878d70cc2ba0c16478d849f07c85669f18155c1243996b0
- 原始产物 SHA256：8c6d942b4ec0a0dedc821c62ebe3f8982007fca093422568a3aa59e942997a38
- 状态：failed
- total=1 passed=0 failed=1

失败明细：
- CI 回归：失败样本必须被报告为 failed: 故意失败：用于验证“失败时才询问是否分析”&#10;&#10;1 !== 0

## 附录报告 / r8-B-r1 r1

- 结果 SHA256：6aeff9a3ae30292c79f13e7e9e869eac0fd92f49ef8ca6d60e6e8b0da554dd54
- 原始产物 SHA256：a63ad0a44a8948f30ebeacdd3d10904c97502894a692264bcd9e32747cb74374
- 状态：succeeded
- total=1 passed=1 failed=0

失败明细：
- 当前报告没有记录失败。

## 判断与下一步

至少一个来源仍有失败：先处理上述失败并重跑对应测试，不把本轮报告作为全通过结果。
