# 测试报告分析

任务：ddab35e276b51bd3f7d950e1a93c369b
授权：attn-228dd2307c63de4d2ab3129a
输入集合 SHA256：81e5c76d116987aba78f4ddf2c6e09638454f209bd824fafeef4e58ce690c2c7

各来源单独核算；不把重复或不同范围的测试合成通过率。

## primary / r8-A-r1 r1

- 结果 SHA256：7190ceb02ec358d3380993b8e7d2727e76c9af41c5bf338052ff4dba423dcc64
- 原始产物 SHA256：34962559ead9679c9d2c9a63f910e8fabb103f18ea7653496df627d536a788f1
- 状态：failed
- total=1 passed=0 failed=1

失败明细：
- CI 回归：失败样本必须被报告为 failed: 故意失败：用于验证“失败时才询问是否分析”&#10;&#10;1 !== 0

## 判断与下一步

至少一个来源仍有失败：先处理上述失败并重跑对应测试，不把本轮报告作为全通过结果。
