# 测试报告分析

任务：e14feafd57a4a509f067662020d6f84e
授权：attn-2c7f443d35d0c9a5783c483c
输入集合 SHA256：7db710eb180e636a436ab97a0a810cc81d6399bb14c0a6d2bc6e1d320e34913b

各来源单独核算；不把重复或不同范围的测试合成通过率。

## primary / r8-A-r2 r2

- 结果 SHA256：4ea329b476da48ea27de86faf7b13e6ffa7ea546fbde3d3094ee6b11f11f8852
- 原始产物 SHA256：60954623134e47c1a0bcf81e9de37c5ff78c8193d626e8730250c65490ba501a
- 状态：failed
- total=1 passed=0 failed=1

失败明细：
- CI 回归：失败样本必须被报告为 failed: 故意失败：用于验证“失败时才询问是否分析”&#10;&#10;1 !== 0

## 附录报告 / r8-B-r1 r1

- 结果 SHA256：38e9ef6bde8eb64ca82496c848b23d6a72837923d1907549d3166268fe0036d9
- 原始产物 SHA256：472bf0594f6ff36862c8155fe78345a7b172e8a9347324052b295ef228feeb81
- 状态：succeeded
- total=1 passed=1 failed=0

失败明细：
- 当前报告没有记录失败。

## 判断与下一步

至少一个来源仍有失败：先处理上述失败并重跑对应测试，不把本轮报告作为全通过结果。
