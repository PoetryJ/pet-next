# 测试报告分析

任务：beacc02ac5697499bfd81d98acdc394c
授权：attn-5b5a3af0a28d9a1c40e952b7
输入集合 SHA256：53c7bd00871f90d17863f53d25e014a40662d681d1d48856a6d69c32f8ea3175

各来源单独核算；不把重复或不同范围的测试合成通过率。

## primary / r8-A-r2 r2

- 结果 SHA256：c8c8b9d2fa2c413cca8afe7efff868ecc172d4585a87c9cecaed9da60294ba9d
- 原始产物 SHA256：5e980ee674ce3769353f6a10e087b83291af9f8c747782b90da5293b0671319c
- 状态：failed
- total=1 passed=0 failed=1

失败明细：
- CI 回归：失败样本必须被报告为 failed: 故意失败：用于验证“失败时才询问是否分析”&#10;&#10;1 !== 0

## 附录报告 / r8-B-r1 r1

- 结果 SHA256：f3c9a4af5103c85b8b4dbae13dc1747d8f1bd6cb30c3f83a4610d5b49b627235
- 原始产物 SHA256：b5025d91f847255c4343204955da5b5f651e7a412ab9e24556fb8b54d3e8dd1b
- 状态：succeeded
- total=1 passed=1 failed=0

失败明细：
- 当前报告没有记录失败。

## 判断与下一步

至少一个来源仍有失败：先处理上述失败并重跑对应测试，不把本轮报告作为全通过结果。
