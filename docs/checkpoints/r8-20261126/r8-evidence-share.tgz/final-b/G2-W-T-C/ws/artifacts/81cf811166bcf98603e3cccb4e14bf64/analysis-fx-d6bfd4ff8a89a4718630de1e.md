# 测试报告分析

任务：81cf811166bcf98603e3cccb4e14bf64
授权：attn-c8e7b5afe047e454defb7197
输入集合 SHA256：79391176ebf702440814f7872422930a5e2f412ef63a15ea63baf87313e0befb

各来源单独核算；不把重复或不同范围的测试合成通过率。

## primary / r8-A-r1 r1

- 结果 SHA256：b40f674946ae036a2d9d290223f77792e167b333d9968f545b74b5ad151368ba
- 原始产物 SHA256：0ba00a1aff3051eb8494f02d1a0318f11ff9dccc7ad52e188902b2afbe6c3ba1
- 状态：succeeded
- total=10 passed=10 failed=0

失败明细：
- 当前报告没有记录失败。

## 附录报告 / r8-B-r1 r1

- 结果 SHA256：75c2b6e7376534fc6bacb8312ccf8bdd584c60730b796a0c7cf86500873f4679
- 原始产物 SHA256：98dd80b628b2b791565114502afd8e94bacedf316456f630422cb52ad3f9c42e
- 状态：failed
- total=1 passed=0 failed=1

失败明细：
- CI 回归：失败样本必须被报告为 failed: 故意失败：用于验证“失败时才询问是否分析”&#10;&#10;1 !== 0

## 判断与下一步

至少一个来源仍有失败：先处理上述失败并重跑对应测试，不把本轮报告作为全通过结果。
