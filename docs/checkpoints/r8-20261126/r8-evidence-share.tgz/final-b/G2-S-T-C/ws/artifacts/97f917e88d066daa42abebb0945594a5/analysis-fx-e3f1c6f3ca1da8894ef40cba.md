# 测试报告分析

任务：97f917e88d066daa42abebb0945594a5
授权：attn-7ec7ab84d418f2fb4b999b3e
输入集合 SHA256：8dfdfb335c50602e0b50a9a2106d4a7830eebec591331cd3f1da166c476180ec

各来源单独核算；不把重复或不同范围的测试合成通过率。

## primary / r8-A-r1 r1

- 结果 SHA256：0a70d0ef821c45eeb03d09e7c101bb85f8565204af6aba422ca58ecc96b7abf3
- 原始产物 SHA256：98a02a03d788df7d1ac19540d668210b693b0558cbfc6ce51a4ff30480002259
- 状态：succeeded
- total=10 passed=10 failed=0

失败明细：
- 当前报告没有记录失败。

## 附录报告 / r8-B-r1 r1

- 结果 SHA256：cbd1910ec6869009c3e28f800178ec8cf32c609b93f3aa364e392d60778714b7
- 原始产物 SHA256：9a11940d11672e82e5270d2dc71492b14b45e486512178536afe7df6805cf1ac
- 状态：failed
- total=1 passed=0 failed=1

失败明细：
- CI 回归：失败样本必须被报告为 failed: 故意失败：用于验证“失败时才询问是否分析”&#10;&#10;1 !== 0

## 判断与下一步

至少一个来源仍有失败：先处理上述失败并重跑对应测试，不把本轮报告作为全通过结果。
