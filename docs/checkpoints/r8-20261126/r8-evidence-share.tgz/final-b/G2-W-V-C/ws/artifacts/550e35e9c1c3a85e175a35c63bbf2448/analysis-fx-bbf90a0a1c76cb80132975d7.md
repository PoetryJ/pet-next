# 测试报告分析

任务：550e35e9c1c3a85e175a35c63bbf2448
授权：attn-efe897add487a7ef8352d2b1
输入集合 SHA256：186e0524b4071a6d73bede0d212f17e34921b09ce8bc62c3afa191b7a4eab31a

各来源单独核算；不把重复或不同范围的测试合成通过率。

## primary / r8-A-r1 r1

- 结果 SHA256：39c9c11aa610a690991fdc05f465459d3527578c2bb4ce44081aedd51eb34ba4
- 原始产物 SHA256：4da1df10ca97c437634890238694976bca2b390cb7af118791f5ebdd8e17835a
- 状态：succeeded
- total=10 passed=10 failed=0

失败明细：
- 当前报告没有记录失败。

## 附录报告 / r8-B-r1 r1

- 结果 SHA256：f3d805e87d9f41147959141aab2f8cabe9ca3cc428a35f9c5edc0fecf0ea503e
- 原始产物 SHA256：2e9beebafe6af7d5f49d91cc4ddde15771f568d11a07e79616ecb3d8ca9a72d1
- 状态：failed
- total=1 passed=0 failed=1

失败明细：
- CI 回归：失败样本必须被报告为 failed: 故意失败：用于验证“失败时才询问是否分析”&#10;&#10;1 !== 0

## 判断与下一步

至少一个来源仍有失败：先处理上述失败并重跑对应测试，不把本轮报告作为全通过结果。
