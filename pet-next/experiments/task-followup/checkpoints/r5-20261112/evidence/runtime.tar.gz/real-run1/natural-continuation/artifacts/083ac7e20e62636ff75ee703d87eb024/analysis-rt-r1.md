# 失败样本分析（rt r1）

- 任务: 083ac7e20e62636ff75ee703d87eb024
- 任务版本: r1
- 结果文件: inbox/E17/result.json
- 结果文件 SHA256: 3f80cfc717f344fcd3e8b57efafe7c84221616fdff4003aa965cbd7049350b4a
- 结果 artifact: inbox/E17/artifact-rt-r1.txt
- 结果 artifact SHA256: e05ec6ee56d646b1bd245cdf96a2eee1b2036dc4ac6f6601a54eae4f0c013c6f
- 输入快照: state/inputs/3f80cfc717f344fcd3e8b57efafe7c84221616fdff4003aa965cbd7049350b4a.json
- 状态: partial
- 指标: total=40 passed=29 failed=11
- 样本数: 40，失败样本: 11

## 失败样本
- s1: timeout: slow path
- s2: parse: bad token
- s3: assert: mismatch
- s4: memory: overflow
- s5: timeout: slow path
- s6: parse: bad token
- s7: assert: mismatch
- s8: memory: overflow
- s9: timeout: slow path
- s10: parse: bad token
- s11: assert: mismatch

## 失败聚类
- assert: 3
- parse: 3
- timeout: 3
- memory: 2

## 下一步
- 复核上述聚类对应的样本输入与预期输出。
- 在分析分支上只改动与聚类相关的处理，不扩大到无关模块。
