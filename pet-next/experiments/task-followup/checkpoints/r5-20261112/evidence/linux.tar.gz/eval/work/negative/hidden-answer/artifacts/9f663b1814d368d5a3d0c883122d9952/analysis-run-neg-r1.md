# 失败样本分析（run-neg r1）

- 任务: 9f663b1814d368d5a3d0c883122d9952
- 任务版本: r1
- 结果文件: inbox/E17/result.json
- 结果文件 SHA256: 5b1b46990810238144cfa9e7ef52b67db31d0ed65c2cf089e1d578bc3ba45412
- 结果 artifact: inbox/E17/artifact-run-neg-r1.txt
- 结果 artifact SHA256: 4334d5293a1c5bbb986b6c0686fee77fd522d0d172a1b416eee88c94127e815c
- 输入快照: state/inputs/5b1b46990810238144cfa9e7ef52b67db31d0ed65c2cf089e1d578bc3ba45412.json
- 状态: partial
- 指标: total=40 passed=29 failed=11
- 样本数: 40，失败样本: 11

## 失败样本
- s1: timeout: slow path
- s2: parse: bad token
- s3: assert: mismatch
- s4: memory: overflow
- s5: timeout: slow path
- s6: parse: bad token
- s7: assert: mismatch
- s8: memory: overflow
- s9: timeout: slow path
- s10: parse: bad token
- s11: assert: mismatch

## 失败聚类
- assert: 3
- parse: 3
- timeout: 3
- memory: 2

## 下一步
- 复核上述聚类对应的样本输入与预期输出。
- 在分析分支上只改动与聚类相关的处理，不扩大到无关模块。
