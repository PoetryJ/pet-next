# 失败样本分析（run-ab r2）

- 任务: 36935d91177b3173d7088499e1603bfc
- 任务版本: r1
- 结果文件: inbox/E17/result.json
- 结果文件 SHA256: 2ea2708fc98067fe01ac119040ac6119726905f465f5a3b4e524a8e4fbad3f7b
- 结果 artifact: inbox/E17/artifact-run-ab-r2.txt
- 结果 artifact SHA256: 2feb625b9a02f6e32331af54b9d8dcd5e41fe46538b88c07cba28c6bcfce2518
- 输入快照: state/inputs/2ea2708fc98067fe01ac119040ac6119726905f465f5a3b4e524a8e4fbad3f7b.json
- 状态: partial
- 指标: total=40 passed=35 failed=5
- 样本数: 40，失败样本: 5

## 失败样本
- s1: timeout: slow path
- s2: parse: bad token
- s3: assert: mismatch
- s4: memory: overflow
- s5: timeout: slow path

## 失败聚类
- timeout: 2
- assert: 1
- memory: 1
- parse: 1

## 下一步
- 复核上述聚类对应的样本输入与预期输出。
- 在分析分支上只改动与聚类相关的处理，不扩大到无关模块。
