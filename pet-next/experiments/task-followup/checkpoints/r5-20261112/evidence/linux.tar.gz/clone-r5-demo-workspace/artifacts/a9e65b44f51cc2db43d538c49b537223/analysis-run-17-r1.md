# 失败样本分析（run-17 r1）

- 任务: a9e65b44f51cc2db43d538c49b537223
- 任务版本: r1
- 结果文件: inbox/E31/result.json
- 结果文件 SHA256: f5d7daeb4937905b0d72361d18bca98e0cbf1cd1cc665e88188d91b8b2d196fc
- 结果 artifact: inbox/E31/artifact-run-17-r1.txt
- 结果 artifact SHA256: 4f10f4d4d8ba3169bbe3f1146332799eda283e8e5edd76496d9e0526b075b158
- 输入快照: state/inputs/f5d7daeb4937905b0d72361d18bca98e0cbf1cd1cc665e88188d91b8b2d196fc.json
- 状态: partial
- 指标: total=40 passed=27 failed=13
- 样本数: 40，失败样本: 13

## 失败样本
- s1: timeout: slow path
- s2: parse: bad token
- s3: assert: mismatch
- s4: memory: overflow
- s5: timeout: slow path
- s6: parse: bad token
- s7: assert: mismatch
- s8: memory: overflow
- s9: timeout: slow path
- s10: parse: bad token
- s11: assert: mismatch
- s12: memory: overflow
- s13: timeout: slow path

## 失败聚类
- timeout: 4
- assert: 3
- memory: 3
- parse: 3

## 下一步
- 复核上述聚类对应的样本输入与预期输出。
- 在分析分支上只改动与聚类相关的处理，不扩大到无关模块。
