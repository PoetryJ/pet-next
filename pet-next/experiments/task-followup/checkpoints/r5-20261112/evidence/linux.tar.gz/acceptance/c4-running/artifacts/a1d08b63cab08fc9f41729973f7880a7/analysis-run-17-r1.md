# 失败样本分析（run-17 r1）

- 任务: a1d08b63cab08fc9f41729973f7880a7
- 任务版本: r1
- 结果文件: inbox/E17/result.json
- 结果文件 SHA256: c81f2be0c412056657b95237f9bacbf5029c1297a7972457774139929d33580d
- 结果 artifact: inbox/E17/artifact-run-17-r1.txt
- 结果 artifact SHA256: f14fd586186ab2c46acc5e8732375b7bbc132cf220d50a50817c928455929123
- 输入快照: state/inputs/c81f2be0c412056657b95237f9bacbf5029c1297a7972457774139929d33580d.json
- 状态: partial
- 指标: total=40 passed=29 failed=11
- 样本数: 40，失败样本: 11

## 失败样本
- s1: timeout: slow path
- s2: parse: bad token
- s3: assert: mismatch
- s4: memory: overflow
- s5: timeout: slow path
- s6: parse: bad token
- s7: assert: mismatch
- s8: memory: overflow
- s9: timeout: slow path
- s10: parse: bad token
- s11: assert: mismatch

## 失败聚类
- assert: 3
- parse: 3
- timeout: 3
- memory: 2

## 下一步
- 复核上述聚类对应的样本输入与预期输出。
- 在分析分支上只改动与聚类相关的处理，不扩大到无关模块。
