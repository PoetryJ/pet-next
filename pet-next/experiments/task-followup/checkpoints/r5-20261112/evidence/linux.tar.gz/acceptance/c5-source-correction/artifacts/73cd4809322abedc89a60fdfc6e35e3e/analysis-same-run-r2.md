# 失败样本分析（same-run r2）

- 任务: 73cd4809322abedc89a60fdfc6e35e3e
- 任务版本: r1
- 结果文件: inbox/E17/result.json
- 结果文件 SHA256: e52b6ec1c518ba4d958dada5735a26aa67b090f56a4024cba5a7d4adcaed3e0f
- 结果 artifact: inbox/E17/artifact-same-run-r2.txt
- 结果 artifact SHA256: 901acd34de128145ddbc4ca6e122139e7c3e9913891e5491bc62ce3742bbbb3a
- 输入快照: state/inputs/e52b6ec1c518ba4d958dada5735a26aa67b090f56a4024cba5a7d4adcaed3e0f.json
- 状态: partial
- 指标: total=40 passed=10 failed=30
- 样本数: 40，失败样本: 30

## 失败样本
- s1: timeout: slow path
- s2: parse: bad token
- s3: assert: mismatch
- s4: memory: overflow
- s5: timeout: slow path
- s6: parse: bad token
- s7: assert: mismatch
- s8: memory: overflow
- s9: timeout: slow path
- s10: parse: bad token
- s11: assert: mismatch
- s12: memory: overflow
- s13: timeout: slow path
- s14: parse: bad token
- s15: assert: mismatch
- s16: memory: overflow
- s17: timeout: slow path
- s18: parse: bad token
- s19: assert: mismatch
- s20: memory: overflow
- s21: timeout: slow path
- s22: parse: bad token
- s23: assert: mismatch
- s24: memory: overflow
- s25: timeout: slow path
- s26: parse: bad token
- s27: assert: mismatch
- s28: memory: overflow
- s29: timeout: slow path
- s30: parse: bad token

## 失败聚类
- parse: 8
- timeout: 8
- assert: 7
- memory: 7

## 下一步
- 复核上述聚类对应的样本输入与预期输出。
- 在分析分支上只改动与聚类相关的处理，不扩大到无关模块。
