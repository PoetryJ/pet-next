R5 independent Linux evidence
See SUMMARY.json and OBSERVATIONS.txt before interpreting green test counts.
Exact commands/cwds/exits: execution.json, bundle-execution.json, r31-execution.json, bounded-execution.json.
Run python3 independent-r5-demo.py for direct SQLite/bytes/service-time checks and duplicate-logical-wait observations.
R4 eval raw/SQLite are in eval/; R5 raw in r5/, its temporary SQLite workspaces in r5-workspaces/ mapped by r5-workspace-map.json. Raw paths remain unchanged.
Original delivery MANIFEST/SHA256SUMS and before/after checks are preserved.
No model/remote endpoint/GPU/product/main/push/merge operations performed.
