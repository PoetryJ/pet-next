# 失败样本分析（run-17 r1）

- 任务: cf819843b5decf7fb71a87102594d3a8
- 任务版本: r1
- 结果文件: inbox/E18/result.json
- 结果文件 SHA256: 0940c07d1760a01b0bade81762a026cd86d80ca93ff6597d6a014c2cb9c15ade
- 结果 artifact: inbox/E18/artifact-run-17-r1.txt
- 结果 artifact SHA256: 4afdaa74be179099eae93a44ed5cbd3840fb2d1153c5423ddbdc2f02c1f03e8b
- 输入快照: state/inputs/0940c07d1760a01b0bade81762a026cd86d80ca93ff6597d6a014c2cb9c15ade.json
- 状态: partial
- 指标: total=40 passed=28 failed=12
- 样本数: 40，失败样本: 12

## 失败样本
- s1: timeout: slow path
- s2: parse: bad token
- s3: assert: mismatch
- s4: memory: overflow
- s5: timeout: slow path
- s6: parse: bad token
- s7: assert: mismatch
- s8: memory: overflow
- s9: timeout: slow path
- s10: parse: bad token
- s11: assert: mismatch
- s12: memory: overflow

## 失败聚类
- assert: 3
- memory: 3
- parse: 3
- timeout: 3

## 下一步
- 复核上述聚类对应的样本输入与预期输出。
- 在分析分支上只改动与聚类相关的处理，不扩大到无关模块。
