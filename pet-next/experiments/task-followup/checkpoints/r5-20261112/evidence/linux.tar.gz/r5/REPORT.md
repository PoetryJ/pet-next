# R5 12 故事：P3 vs NeedRule(N1)

生成时间：2026-11-12T10:07:04.867Z

固定分母：12 条故事 × 2 策略 = 24 runs；必完成 10 条；必要决策 9 项。

| 策略 | 有效完成 | 必需问题(产生/可见/回答/行动正确) | 漏提案 | 未触达(已过期) | censored | 通知 | 重复 | 过期通知 | 取消后 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| N1 | 10/10 (100.0%) | 9/9/9/9 (共 9) | 0 | 0 | 0 | 12 | 0 | 0 | 0 |
| P3 | 10/10 (100.0%) | 9/9/9/9 (共 9) | 0 | 0 | 0 | 12 | 0 | 0 | 0 |

说明：pending 是 censored（故事结束时尚未到最迟时刻），不算成功也不算漏办；
未回复不是“无用提醒”的证据；本轮没有人工阅读或真实用户评价。

## 逐条结果

| 故事 | 族 | 划分 | 策略 | 有效完成 | 必需问题 | 通知 | wake(fired/stale) |
| --- | --- | --- | --- | --- | --- | --- | --- |
| R5-01a | transient | dev | N1 | yes | — | 1 | 1/0 |
| R5-01b | transient | dev | N1 | yes | insufficient_result:visible | 2 | 1/0 |
| R5-02a | digest | dev | N1 | yes | — | 0 | 0/0 |
| R5-02b | digest | dev | N1 | yes | insufficient_result:visible | 1 | 0/0 |
| R5-03a | quiet | dev | N1 | yes | insufficient_result:visible | 1 | 4/0 |
| R5-03b | quiet | dev | N1 | yes | insufficient_result:visible | 1 | 0/0 |
| R5-04a | replace | heldout | N1 | yes | insufficient_result:visible | 1 | 1/0 |
| R5-04b | replace | heldout | N1 | yes | insufficient_result:visible | 1 | 1/0 |
| R5-05a | preference | heldout | N1 | no | insufficient_result:visible | 1 | 1/0 |
| R5-05b | preference | heldout | N1 | yes | insufficient_result:visible | 1 | 0/0 |
| R5-06a | lifecycle | heldout | N1 | no | — | 1 | 0/0 |
| R5-06b | lifecycle | heldout | N1 | yes | insufficient_result:visible | 1 | 1/0 |
| R5-01a | transient | dev | P3 | yes | — | 1 | 1/0 |
| R5-01b | transient | dev | P3 | yes | insufficient_result:visible | 2 | 1/0 |
| R5-02a | digest | dev | P3 | yes | — | 0 | 0/0 |
| R5-02b | digest | dev | P3 | yes | insufficient_result:visible | 1 | 0/0 |
| R5-03a | quiet | dev | P3 | yes | insufficient_result:visible | 1 | 2/0 |
| R5-03b | quiet | dev | P3 | yes | insufficient_result:visible | 1 | 0/0 |
| R5-04a | replace | heldout | P3 | yes | insufficient_result:visible | 1 | 1/0 |
| R5-04b | replace | heldout | P3 | yes | insufficient_result:visible | 1 | 1/0 |
| R5-05a | preference | heldout | P3 | no | insufficient_result:visible | 1 | 1/0 |
| R5-05b | preference | heldout | P3 | yes | insufficient_result:visible | 1 | 0/0 |
| R5-06a | lifecycle | heldout | P3 | no | — | 1 | 0/0 |
| R5-06b | lifecycle | heldout | P3 | yes | insufficient_result:visible | 1 | 1/0 |

## 结论（只报计数）

N1 相对 P3：可见 +0、回答 +0、通知 +0、漏提案 +0。

本组冻结故事**不支持** NeedRule 更少打扰或更高触达；两份规则在这些故事上完成与触达相同，N1 没有可报告的收益。

## 不能声称

- 没有模型、真实用户、远程任务或真实通知；delivery 仍是本地模拟通道。
- 没有 12 小时稳定性；实时演示只跑了秒级序列（见交付 r5-demo 日志）。
- pending/censored 不等于“将来会成功”。
