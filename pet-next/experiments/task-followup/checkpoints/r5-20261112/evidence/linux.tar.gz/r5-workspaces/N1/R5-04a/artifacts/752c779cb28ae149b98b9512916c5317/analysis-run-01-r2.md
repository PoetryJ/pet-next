# 失败样本分析（run-01 r2）

- 任务: 752c779cb28ae149b98b9512916c5317
- 任务版本: r1
- 结果文件: inbox/E41/result.json
- 结果文件 SHA256: 0f92670bf6b7cbeca7384dc346ca388652bddd11bdfa26b93f577feb8996eca8
- 结果 artifact: inbox/E41/artifact-run-01-r2.txt
- 结果 artifact SHA256: 434ed6cb7dd35f75e025e1e6d0c02b56b40132bd65d506263658465ac9e40f8c
- 输入快照: state/inputs/0f92670bf6b7cbeca7384dc346ca388652bddd11bdfa26b93f577feb8996eca8.json
- 状态: partial
- 指标: total=40 passed=25 failed=15
- 样本数: 40，失败样本: 15

## 失败样本
- s1: timeout: slow path
- s2: parse: bad token
- s3: assert: mismatch
- s4: memory: overflow
- s5: timeout: slow path
- s6: parse: bad token
- s7: assert: mismatch
- s8: memory: overflow
- s9: timeout: slow path
- s10: parse: bad token
- s11: assert: mismatch
- s12: memory: overflow
- s13: timeout: slow path
- s14: parse: bad token
- s15: assert: mismatch

## 失败聚类
- assert: 4
- parse: 4
- timeout: 4
- memory: 3

## 下一步
- 复核上述聚类对应的样本输入与预期输出。
- 在分析分支上只改动与聚类相关的处理，不扩大到无关模块。
