import pathlib,json,sqlite3,sys,collections
raw=pathlib.Path(sys.argv[1]);gold=pathlib.Path(sys.argv[2]);out=pathlib.Path(sys.argv[3]);out.mkdir(exist_ok=True,parents=True)
legacy='--legacy' in sys.argv;checks=0;failed=[];runs=[]
def ck(x,label):
 global checks
 checks+=1
 if not x:failed.append(label)
def ident(x):return all(isinstance(x.get(k),str) and bool(x[k]) for k in ['decisionId','ticketId','assignmentId']) and isinstance(x.get('taskRevision'),int) and x['taskRevision']>=1
for p in sorted(raw.glob('*/*.json')):
 d=json.loads(p.read_text());tag=d['policy']+'/'+p.stem;g=json.loads((gold/(d['trajectoryId']+'.json')).read_text())['variants'][d['variantId']]
 if not legacy:
  ck(d['schema']=='pet-followup-raw/v2',tag+':rawv2')
  for typ in ['asks','proposals','attentions']:
   for a in d[typ]:ck(ident(a),tag+':identity_complete:'+typ+':'+str(a.get('decisionId')))
  for a in d['asks']:
   same=[q for q in d['proposals'] if q['decisionId']==a['decisionId']]
   ck(len(same)==1 and all(a[k]==same[0][k] for k in ['ticketId','taskRevision','assignmentId','reasonCode','decisionKey','outcome']),tag+':ask_proposal_chain:'+a['decisionId'])
 r={'run':p.stem,'policy':d['policy'],'required':len(g['requiredDecisions']),'produced':0,'visible':0,'answered':0,'details':[]}
 for kind in g['requiredDecisions']:
  asks=[a for a in d['asks'] if a['reasonCode']==kind and a['outcome']!='invalidated']
  status='not_proposed'
  if asks:
   r['produced']+=1;a=max(asks,key=lambda a:(a.get('taskRevision',0),a['at'],a.get('decisionId','')))
   if not ident(a):status='identity_missing'
   else:
    aa=[x for x in d['attentions'] if x.get('decisionId')==a['decisionId']]
    if len(aa)!=1:status='identity_missing_or_ambiguous'
    else:
     x=aa[0]
     if not ident(x) or any(x[k]!=a[k] for k in ['ticketId','taskRevision','assignmentId']):status='identity_missing_or_mismatch'
     elif not (x['deliveredAt'] or x['presentedAt']):status='not_visible'
     else:
      r['visible']+=1;r['answered']+=x['state']=='answered';status='answered' if x['state']=='answered' else 'visible'
  r['details'].append({'kind':kind,'status':status})
 runs.append(r)
summary={}
for policy in ['P0','P1','P2','P3']:
 rr=[r for r in runs if r['policy']==policy];row={k:sum(r[k] for r in rr) for k in ['required','produced','visible','answered']};row.update(notProposed=row['required']-row['produced'],notVisible=row['required']-row['visible'],notAnswered=row['required']-row['answered']);summary[policy]=row
res={'rawDir':str(raw),'legacy':legacy,'checks':checks,'failed':failed,'policies':summary,'runs':runs}
(out/'identity.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({k:res[k] for k in ['legacy','checks','failed','policies']},indent=2));sys.exit(1 if failed else 0)
