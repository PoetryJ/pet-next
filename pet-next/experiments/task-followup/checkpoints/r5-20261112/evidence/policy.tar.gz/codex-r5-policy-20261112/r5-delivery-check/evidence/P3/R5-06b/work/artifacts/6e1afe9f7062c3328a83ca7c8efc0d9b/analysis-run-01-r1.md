# 失败样本分析（run-01 r1）

- 任务: 6e1afe9f7062c3328a83ca7c8efc0d9b
- 任务版本: r1
- 结果文件: inbox/E41/result.json
- 结果文件 SHA256: a50216b40d886c4e1e95e4d4945c2e1b7023b42dd97aae08600b23a70dec19a1
- 结果 artifact: inbox/E41/artifact-run-01-r1.txt
- 结果 artifact SHA256: 707e438238e59b5d03b89927a103078c74746f5a19433a32e5ec8b16246e91a9
- 输入快照: state/inputs/a50216b40d886c4e1e95e4d4945c2e1b7023b42dd97aae08600b23a70dec19a1.json
- 状态: partial
- 指标: total=40 passed=28 failed=12
- 样本数: 40，失败样本: 12

## 失败样本
- s1: timeout: slow path
- s2: parse: bad token
- s3: assert: mismatch
- s4: memory: overflow
- s5: timeout: slow path
- s6: parse: bad token
- s7: assert: mismatch
- s8: memory: overflow
- s9: timeout: slow path
- s10: parse: bad token
- s11: assert: mismatch
- s12: memory: overflow

## 失败聚类
- assert: 3
- memory: 3
- parse: 3
- timeout: 3

## 下一步
- 复核上述聚类对应的样本输入与预期输出。
- 在分析分支上只改动与聚类相关的处理，不扩大到无关模块。
