# 失败样本分析（run-01 r1）

- 任务: b154a68734997f0b2e2e939bc3e3158b
- 任务版本: r1
- 结果文件: inbox\E17\result.json
- 结果文件 SHA256: 1aa87d9dcb7b777c768dcf8a347e34287acabc1e173a8e93a71a9945dd0888d6
- 结果 artifact: inbox/E17/artifact-run-01-r1.txt
- 结果 artifact SHA256: 875573bd218c7da4dd17b0c15aca63d08b3dfd557820f8788bfd59f12a9958a6
- 输入快照: state\inputs\1aa87d9dcb7b777c768dcf8a347e34287acabc1e173a8e93a71a9945dd0888d6.json
- 状态: partial
- 指标: total=40 passed=29 failed=11
- 样本数: 40，失败样本: 11

## 失败样本
- s1: timeout: slow path
- s2: parse: bad token
- s3: assert: mismatch
- s4: memory: overflow
- s5: timeout: slow path
- s6: parse: bad token
- s7: assert: mismatch
- s8: memory: overflow
- s9: timeout: slow path
- s10: parse: bad token
- s11: assert: mismatch

## 失败聚类
- assert: 3
- parse: 3
- timeout: 3
- memory: 2

## 下一步
- 复核上述聚类对应的样本输入与预期输出。
- 在分析分支上只改动与聚类相关的处理，不扩大到无关模块。
