#!/usr/bin/env python3
"""Independent R4.1 audit. Standard-library only; imports no product scorer.
Metrics are derived from raw lists and SQLite/artifact byte chains. Raw.metrics and
completionCheck.ok are deliberately not used as truth. Gold only supplies expected opportunities.
"""
import json,pathlib,sys,sqlite3,hashlib,collections,datetime,shutil
rawdir=pathlib.Path(sys.argv[1]);goldpath=pathlib.Path(sys.argv[2]);out=pathlib.Path(sys.argv[3]);out.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def ts(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
def dump(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
gold={p.stem:load(p)['variants'] for p in goldpath.glob('*.json')}
fail=[];runs=[];fingerprints={};totalchecks=0

def check(ok,label):
 global totalchecks
 totalchecks+=1
 if not ok:fail.append(label)

for p in sorted(rawdir.glob('*/*.json')):
 d=load(p);run=p.stem;pol=d['policy'];tag=pol+'/'+run;g=gold[d['trajectoryId']][d['variantId']]
 w=(pathlib.Path(sys.argv[4])/(pol+'-'+run)) if len(sys.argv)>4 else pathlib.Path(d['workspace']);db=w/'state/followup.sqlite'
 def wp(rel):return w/pathlib.Path(rel.replace(chr(92),'/'))
 c=sqlite3.connect('file:'+str(db)+'?mode=ro',uri=True);c.row_factory=sqlite3.Row
 tasks=[dict(x) for x in c.execute('select * from tasks')];check(len(tasks)==1,tag+':task count');t=tasks[0]
 check(t['status']==d['final']['status'],tag+':raw/database status')
 # Read authoritative database, effect, receipt, frozen input, and live bytes independently.
 completed=t['status']=='completed';chain=[]
 if completed:
  r=json.loads(t['result_json']);a=json.loads(t['analysis_json']);comp=json.loads(t['completion_json'])
  receipts=[dict(x) for x in c.execute('select * from receipts where receipt_id=?',(comp['receiptId'],))]
  chain.append(len(receipts)==1)
  if receipts:
   rec=receipts[0];fx=dict(c.execute('select * from effects where effect_id=?',(rec['effect_id'],)).fetchone());ref=json.loads(rec['input_ref_json'])
   chain += [rec['ok']==1,rec['inputs_verified']==1,rec['needs_reconciliation']==0,fx['state']=='succeeded',json.loads(fx['input_ref_json'])==ref,a['inputRef']==ref,comp['inputRef']==ref]
   chain += [ref['taskId']==t['ticket_id'],ref['taskRevision']==t['task_revision'],ref['assignmentId']==t['assignment_id']]
   chain += [ref[k]==r[k] for k in ['runId','revision','resultFileSha','artifactSha','resultPath','artifactPath']]
   chain += [sha(wp(ref['resultPath']))==ref['resultFileSha'],sha(wp(ref['artifactPath']))==ref['artifactSha'],sha(w/'state/inputs'/ (ref['resultFileSha']+'.json'))==ref['resultFileSha']]
   chain += [rec['output_path']==a['artifactPath'],rec['output_sha256']==a['artifactSha']==comp['artifactSha'],sha(wp(rec['output_path']))==rec['output_sha256']]
   chain += [not list(c.execute("select 1 from effects where state in ('running','needs_reconciliation')"))]
  check(all(chain),tag+':completed input/receipt/artifact chain')
 valid=completed and all(chain)
 check(valid==d['final']['validCompletion'],tag+':validCompletion agrees independently')
 # Monotonic arrays; paired chronology and explicit IANA timezone/config.
 for arr in ['timeTrace','steps','observations','driverLog','proposals','notifications']:
  stamps=[ts(x['at']) for x in d[arr]]
  check(stamps==sorted(stamps),tag+':monotonic '+arr)
  check(all(ts(d['clockStart'])<=x<=ts(d['finalClock']) for x in stamps),tag+':bounded '+arr)
 check(d['timezone']==d['quiet']['timezone'],tag+':timezone consistent')
 import zoneinfo
 zoneinfo.ZoneInfo(d['timezone'])
 cfg={'rule':'followup-rules/v1','id':pol,'config':{'failureThreshold':0.15,'cooldownMs':1800000,'quiet':d['quiet']}}
 expected_config_sha=hashlib.sha256(json.dumps(cfg,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 check(d['configSha']==d['policyConfigSha']==expected_config_sha,tag+':configuration SHA independently recomputed')
 fingerprints[tag]={'timezone':d['timezone'],'quiet':d['quiet'],'timeTrace':d['timeTrace'],'configSha':d['configSha']}
 actual_notifs=d['notifications'];atts=d['attentions'];asks=[q for q in d['proposals'] if q['kind']=='ask_user' and q['outcome'] not in ['invalidated','stale','rejected']]
 def delivered(a):
  return any(n['attentionId']==a['attentionId'] and n.get('deliveredAt') and n['deliveredAt']==a.get('deliveredAt') and ts(n['at'])<=ts(n['deliveredAt']) for n in actual_notifs)
 def visible(a):return delivered(a) or bool(a.get('presentedAt'))
 attention_decision={x['attention_id']:x['decision_id'] for x in c.execute('select attention_id,decision_id from attentions')}
 def linked(q,a):return attention_decision[a['attentionId']]==q['decisionId'] and a['taskRevision']==q['taskRevision']
 produced=[];seen=[];answered=[]
 for reason in g['requiredDecisions']:
  candidates=[q for q in asks if q['reasonCode']==reason]
  aa=[a for a in atts if any(linked(q,a) for q in candidates)]
  if candidates:produced.append(reason)
  if any(visible(a) for a in aa):seen.append(reason)
  if any(visible(a) and a['state']=='answered' for a in aa):answered.append(reason)
 for a in atts:
  if a.get('deliveredAt'):check(delivered(a),tag+':matching delivered notification '+a['attentionId'])
  if a['state']=='answered':
   v=[x for x in [a.get('deliveredAt'),a.get('presentedAt')] if x]
   check(bool(v) and bool(a.get('answeredAt')) and min(map(ts,v))<=ts(a['answeredAt']),tag+':visible before answer '+a['attentionId'])
 # Actual evidence must not contain evaluation gold-key payloads; source import review reported separately.
 forbidden=['"mustComplete"','"requiredDecisions"','"maxNotifications"','"expectedStatus"']
 runtime_payload=json.dumps([json.loads(x['payload_json']) for x in c.execute('select payload_json from followup_events')],ensure_ascii=False)+t['goal_json']
 check(not any(x in runtime_payload for x in forbidden),tag+':no gold keys in events/goal')
 buckets=collections.Counter(n['deliveredAt'][:13] for n in actual_notifs if n.get('deliveredAt'))
 quota_violations=sum(n>d['quiet']['reminderQuotaPerHour'] for n in buckets.values())
 rr={'run':run,'policy':pol,'group':d['group'],'mustComplete':g['mustComplete'],'stateCompleted':completed,'validCompleted':valid,'chainChecks':len(chain),'required':g['requiredDecisions'],'produced':produced,'visible':seen,'answered':answered,'unproduced':list(set(g['requiredDecisions'])-set(produced)),'unreached':list(set(g['requiredDecisions'])-set(seen)),'unansweredRequired':list(set(g['requiredDecisions'])-set(answered)),'notifications':len(actual_notifs),'delivered':sum(bool(n.get('deliveredAt')) for n in actual_notifs),'presented':sum(bool(n.get('presentedAt')) for n in actual_notifs),'quotaViolations':quota_violations,'finalStage':t['stage'],'finalReasons':d['final']['completionCheck']['reasons'],'rawSha256':sha(p),'databaseSha256':sha(db)}
 runs.append(rr)
 # Archive only independent proof for completed chains and failure-relevant P3 cases.
 if completed or run=='T09-a' or (pol=='P3' and run in ['T10-a','T15-a','T16-a']):
  ev=out/'evidence'/pol/run;ev.mkdir(parents=True,exist_ok=True)
  shutil.copy2(p,ev/'raw.json');shutil.copy2(db,ev/'followup.sqlite')
  if completed:
   for srcfile in [wp(ref['resultPath']),wp(ref['artifactPath']),wp(rec['output_path']),w/'state/inputs'/(ref['resultFileSha']+'.json')]:
    target=ev/'workspace'/srcfile.relative_to(w);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(srcfile,target)
 c.close()

for run in sorted({r['run'] for r in runs}):
 group=[fingerprints[p+'/'+run] for p in ['P0','P1','P2','P3']]
 check(all(x['quiet']==group[0]['quiet'] for x in group),run+':all policy config equal')
 check(all(x['timeTrace']==group[0]['timeTrace'] for x in group),run+':all policy timeTrace equal')
summary={}
for pol in ['P0','P1','P2','P3']:
 rr=[r for r in runs if r['policy']==pol]
 summary[pol]={'opportunities':len(rr),'mustComplete':sum(r['mustComplete'] for r in rr),'stateCompleted':sum(r['stateCompleted'] for r in rr),'validCompleted':sum(r['validCompleted'] for r in rr),'validRequiredCompletion':sum(r['mustComplete'] and r['validCompleted'] for r in rr),'required':sum(len(r['required']) for r in rr),'produced':sum(len(r['produced']) for r in rr),'visible':sum(len(r['visible']) for r in rr),'answered':sum(len(r['answered']) for r in rr),'unproduced':sum(len(r['unproduced']) for r in rr),'unreached':sum(len(r['unreached']) for r in rr),'unansweredRequired':sum(len(r['unansweredRequired']) for r in rr),'notifications':sum(r['notifications'] for r in rr),'delivered':sum(r['delivered'] for r in rr),'presented':sum(r['presented'] for r in rr),'quotaViolations':sum(r['quotaViolations'] for r in rr)}
check(len(runs)==72,'72 runs')
res={'rawSource':str(rawdir),'checks':totalchecks,'failed':fail,'policies':summary,'runs':runs}
dump(out/'result.json',res);dump(out/'time-config.json',fingerprints)
print(json.dumps({'checks':totalchecks,'failed':fail,'policies':summary},ensure_ascii=False,indent=2))

sys.exit(1 if fail else 0)
