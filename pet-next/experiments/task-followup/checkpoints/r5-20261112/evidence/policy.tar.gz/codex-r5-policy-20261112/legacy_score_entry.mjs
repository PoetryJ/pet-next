import {writeFileSync} from 'node:fs';import {join} from 'node:path';import {pathToFileURL} from 'node:url';
const {scoreAll}=await import(pathToFileURL(join(process.argv[2],'eval/score.ts')).href);
const result=scoreAll(process.argv[3],join(process.argv[2],'gold'));writeFileSync(process.argv[4],JSON.stringify(result,null,2));
console.log(JSON.stringify(Object.fromEntries(Object.entries(result.policies).map(([p,s])=>[p,{produced:s.requiredProduced,visible:s.requiredVisible,answered:s.requiredAnswered,reasons:[...new Set(s.notVisibleDetail.map(x=>x.reason))]}])),null,2));
