# 失败样本分析（run-01 r2）

- 任务: 7b7386c1f116d978a9f322f447f69891
- 任务版本: r1
- 结果文件: inbox/E41/result.json
- 结果文件 SHA256: d5222023ebc7bdccc7e8777dfd1ab8756979e1c1f40281374a7282eac1ca5ab7
- 结果 artifact: inbox/E41/artifact-run-01-r2.txt
- 结果 artifact SHA256: d35c5038df9a1e48ad56d2529e1ec4970be6714184e49272ac037c392b829c8b
- 输入快照: state/inputs/d5222023ebc7bdccc7e8777dfd1ab8756979e1c1f40281374a7282eac1ca5ab7.json
- 状态: partial
- 指标: total=40 passed=26 failed=14
- 样本数: 40，失败样本: 14

## 失败样本
- s1: timeout: slow path
- s2: parse: bad token
- s3: assert: mismatch
- s4: memory: overflow
- s5: timeout: slow path
- s6: parse: bad token
- s7: assert: mismatch
- s8: memory: overflow
- s9: timeout: slow path
- s10: parse: bad token
- s11: assert: mismatch
- s12: memory: overflow
- s13: timeout: slow path
- s14: parse: bad token

## 失败聚类
- parse: 4
- timeout: 4
- assert: 3
- memory: 3

## 下一步
- 复核上述聚类对应的样本输入与预期输出。
- 在分析分支上只改动与聚类相关的处理，不扩大到无关模块。
