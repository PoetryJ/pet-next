# 失败样本分析（run-01 r1）

- 任务: 84be0660835438416d525f62dcd22f65
- 任务版本: r1
- 结果文件: inbox/E41/result.json
- 结果文件 SHA256: 7ff29ad59aef69b939ea47b42061eaee722ed0b7b8b59b4f26f41b637efd5daf
- 结果 artifact: inbox/E41/artifact-run-01-r1.txt
- 结果 artifact SHA256: 8361b38f7e0dbccc0f2f7137147cec3592108bec5f249b643efd11754d79c5df
- 输入快照: state/inputs/7ff29ad59aef69b939ea47b42061eaee722ed0b7b8b59b4f26f41b637efd5daf.json
- 状态: failed
- 指标: total=40 passed=0 failed=40
- 样本数: 40，失败样本: 40

## 失败样本
- s1: timeout: slow path
- s2: parse: bad token
- s3: assert: mismatch
- s4: memory: overflow
- s5: timeout: slow path
- s6: parse: bad token
- s7: assert: mismatch
- s8: memory: overflow
- s9: timeout: slow path
- s10: parse: bad token
- s11: assert: mismatch
- s12: memory: overflow
- s13: timeout: slow path
- s14: parse: bad token
- s15: assert: mismatch
- s16: memory: overflow
- s17: timeout: slow path
- s18: parse: bad token
- s19: assert: mismatch
- s20: memory: overflow
- s21: timeout: slow path
- s22: parse: bad token
- s23: assert: mismatch
- s24: memory: overflow
- s25: timeout: slow path
- s26: parse: bad token
- s27: assert: mismatch
- s28: memory: overflow
- s29: timeout: slow path
- s30: parse: bad token
- s31: assert: mismatch
- s32: memory: overflow
- s33: timeout: slow path
- s34: parse: bad token
- s35: assert: mismatch
- s36: memory: overflow
- s37: timeout: slow path
- s38: parse: bad token
- s39: assert: mismatch
- s40: memory: overflow

## 失败聚类
- assert: 10
- memory: 10
- parse: 10
- timeout: 10

## 下一步
- 复核上述聚类对应的样本输入与预期输出。
- 在分析分支上只改动与聚类相关的处理，不扩大到无关模块。
