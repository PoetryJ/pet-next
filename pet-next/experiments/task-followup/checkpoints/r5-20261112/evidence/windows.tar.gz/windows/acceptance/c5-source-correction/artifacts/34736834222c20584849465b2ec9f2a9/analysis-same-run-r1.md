# 失败样本分析（same-run r1）

- 任务: 34736834222c20584849465b2ec9f2a9
- 任务版本: r1
- 结果文件: inbox\E17\result.json
- 结果文件 SHA256: 7a369797b2e90879ea24334bcdee1abd8fce4fb3316db4343376ddc858e57be5
- 结果 artifact: inbox/E17/artifact-same-run-r1.txt
- 结果 artifact SHA256: c8ff58ab073ac8439c3c2b9999d60f87d43337d89e8dde9b22fd9932073b1e89
- 输入快照: state\inputs\7a369797b2e90879ea24334bcdee1abd8fce4fb3316db4343376ddc858e57be5.json
- 状态: partial
- 指标: total=40 passed=29 failed=11
- 样本数: 40，失败样本: 11

## 失败样本
- s1: timeout: slow path
- s2: parse: bad token
- s3: assert: mismatch
- s4: memory: overflow
- s5: timeout: slow path
- s6: parse: bad token
- s7: assert: mismatch
- s8: memory: overflow
- s9: timeout: slow path
- s10: parse: bad token
- s11: assert: mismatch

## 失败聚类
- assert: 3
- parse: 3
- timeout: 3
- memory: 2

## 下一步
- 复核上述聚类对应的样本输入与预期输出。
- 在分析分支上只改动与聚类相关的处理，不扩大到无关模块。
