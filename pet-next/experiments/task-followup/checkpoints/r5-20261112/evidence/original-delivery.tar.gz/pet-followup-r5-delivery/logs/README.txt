本目录是原始命令输出（未经二次编辑）。
环境：Linux 5.4.119-19.0009.28 / Node v22.20.0
Node：/root/.codebuddy-server-cn/bin/stable-b72e1c95b338c0ad905fa55af1a5011cf4093a9f/node
工作目录：/data3/DATA/project/project_meishijiang/petmem-followup-r5/pet-next/experiments/task-followup
冻结提交：ff7e1b82c70fae098dc93abc8a1c9bac46fac592

文件 / 命令 / 退出码 / 结果：
  test.log                  node run.mjs test                     0   93/93
  typecheck.log             node run.mjs typecheck                0
  demo.log                  node run.mjs demo                     0   R4 demo 35 项
  r5-demo.log               node run.mjs r5-demo                  0   23+ 项（真实时钟）
  eval.log                  node run.mjs eval                     0   72 runs
  verify-eval.log           node run.mjs verify-eval              0   0 失配
  crosscheck-r4.log         node run.mjs crosscheck --external …  0   0 差异
  negative.log              node run.mjs negative                 0   10/10 DETECTED
  acceptance.log            node tools/r41-acceptance.mjs          0   27/27
  audit.log                 node tools/audit.mjs                   0   0 禁用项 / R3.1 diff 0
  upstream.log              upstream vitest run                    0   144/144
  r31-regression.log        memory-consistency --all               0   192/192 + G1/P1/P2
  r31-fixture-*.log         四个负控 fixture                       1   detected
  g0-before.log             复核包 identity-probes（基线）          1   3 失败
  g0-after.log              复核包 identity-probes（修复）          0   7/7
  r5-eval.log               node run.mjs r5-eval                   0   24 runs
  r5-crosscheck.log         eval/r5/crosscheck.mjs                 0   0 差异
  r5-negative.log           eval/r5/negative/all.mjs               0   6/6 DETECTED

干净 bundle 克隆（HEAD ff7e1b8，外部改动 0）：
  bundle-test.log           93/93
  bundle-r5-demo.log        23+ 项
  bundle-r5-eval.log        24 runs
  bundle-r5-negative.log    6/6
  bundle-eval.log           72 runs
  bundle-verify-eval.log    0 失配

说明：
- 负控子进程 exit 1 = 检出；harness exit 0。
- 诊断退出码（崩溃 42、reconcile 4、回答被拒 3/6、真实时钟 6）在原始 JSON/SQLite 的 exit 字段。
- 有界运行：bounded-run/service.log 与 service-status.json（30s、6 次唤醒）。
