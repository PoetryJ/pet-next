# R5 分工与接口冻结

## 角色与文件归属

| 角色 | 独占文件 | 交付 |
| --- | --- | --- |
| G0（负责人） | `eval/score.ts`、`tests/r42-score.test.ts` | 身份存在性/类型校验，7 项新测试 |
| A（运行时） | `runtime/engine.ts`、`runtime/db.ts`、`runtime/scheduler.ts`、`tests/r5-scheduler.test.ts` | 持久 wake_jobs、到期重判、重启/取消/幂等 |
| B（基线） | `decision/r5/`、`tests/r5-need-rule.test.ts` | NeedRule N1 与冻结参数 |
| C（评估） | `eval/r5/`、`fixtures/r5/`、`gold/r5/`、`tests/r5-score.test.ts` | 12 故事、独立评分、交叉核对、负控 |
| 负责人（集成） | `contracts.ts`、`runtime/build.ts`、`service/`、`cli/`、`demo/`、文档 | 接口冻结、服务、演示、门与交付 |

未改动：`decision/rules.ts`（P3 原样）、R4 `eval/score.ts` 的唯一改动是 G0 入口校验、
R4 `gold/`、`fixtures/trajectories/`、R4 参数。

## 冻结的公共接口

1. `WakeJob` / `WakeScheduleInput` / `WakeHandleResult`（contracts.ts）
   jobId 包含 ticket/revision/reason/decisionId/dueAt，因此每次到期是新行，旧行保留 done/cancelled。
2. `RuntimeOptions.wakeAfterMs` 与 `BuildRuntimeOptions.wakeAfterMs`：defer 重判的压缩下限；
   评估不设置（默认 10 分钟），演示显式设置 2–5 秒，写入 service.json。
3. `FollowupRuntime.scheduler` / `listWakeJobs()` / `nextWakeAt()` / `wakeDue()` / `wakeJob()` / `reevaluate()`。
4. `BuildRuntimeOptions.decision?: DecisionPort`：R5 注入 NeedRule，不把 N1 塞进 R4 的 PolicyId 常量。
5. `DecisionPort.id` 扩为 `PolicyId | 'N1'`；`POLICY_IDS` 仍是 P0–P3，R4 评分表不变。
6. R5 raw schema `pet-followup-r5-raw/v1`；R5 评分 schema `pet-followup-r5-scores/v1`。

## 选择规则（R5 评分）

当前有效 ask = 未被撤销的 ask 中 `(taskRevision, at)` 最大者；attention 只按 decisionId 连接，
ticket/revision/assignment 必须齐全且相等；缺失/歧义 fail closed。
visible 只认落在 gold `[earliest, latest]` 内的 delivered/presented；晚于 latest 记 overdue；
未送达且未到 latest 记 pending（censored）；其余记 missed。
