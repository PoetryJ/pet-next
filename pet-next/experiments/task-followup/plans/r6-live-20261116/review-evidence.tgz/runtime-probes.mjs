import { DatabaseSync } from 'node:sqlite';
import { createHash } from 'node:crypto';
import { writeFileSync } from 'node:fs';
import { createConditionsHandle } from './source/pet-next/experiments/task-followup/service/capability-conditions.ts';
import { makeContext } from './source/pet-next/experiments/task-followup/capability/conditions/context.ts';
import { evaluate } from './source/pet-next/experiments/task-followup/capability/conditions/kernel.ts';
import { CapabilityMemoryStore } from './source/pet-next/experiments/task-followup/capability/memory/store.ts';

const sha=x=>createHash('sha256').update(x).digest('hex');
const NOW='2026-11-16T02:00:00.000Z';
const TASK='A';
const template={actionId:'ask-A',source:'baseline-rule-menu',kind:'ask_user',reasonCode:'needs_user_choice',reasonText:'',question:'现在处理吗？',options:[{id:'go',label:'处理'},{id:'later',label:'等'}],evidenceRefs:[]};
const snapshot=()=>({protocol:'pet-assessment/v1',identity:{requestId:'r1',ticketId:TASK,taskRevision:1,assignmentId:'a1',memoryCursor:0,eventCursor:0,round:1,sourceRefs:[]},now:NOW,
 task:{ticketId:TASK,title:'A测试',goal:'结果回来再问我',goalCondition:{kind:'analysis',minSamples:1,requirePassed:true},taskRevision:1,assignmentId:'a1',stage:'result_received',status:'active',createdAt:NOW,updatedAt:NOW,eventCursor:0,memoryCursor:0,evidence:[],attempt:0,diagnostics:[],result:{runId:'runA',revision:1,status:'succeeded',metrics:{total:1,passed:1,failed:0,score:null},artifactPath:null,artifactSha:sha('artifact'),resultPath:null,resultFileSha:sha('result')}},evidence:[],history:[],openAttention:null,lastAnswer:null,attempt:1,inputReady:true,goalSatisfied:false,quiet:{fromHour:22,toHour:8,minGapMs:0},actionMenu:[template]});

function fixture({availabilityBug=false,unsupported=false}={}){
 const purposes=[];
 const client={kind:'fixture',purposes,async complete(req){
  purposes.push(req.purpose);
  const input=JSON.parse(req.messages[1].content);let value;
  if(req.purpose==='memory-extract'){
   const ts=input.turnsToExtract??[];
   value={coverage:ts.map(t=>({turnId:t.id,status:'extracted'})),items:ts.flatMap(t=>availabilityBug?[
    {key:'availability',value:'busy',scope:{level:'global',id:null},quotes:[{turnId:t.id,text:'我现在很忙'}]},
    {key:'expectedUpdateAt',value:'2026-11-16T18:00:00.000Z',scope:{level:'task',id:TASK},quotes:[{turnId:t.id,text:'下一份结果预计2026-11-16T18:00:00.000Z'}]}
   ]:[{key:'availability',value:'available',scope:{level:'global',id:null},quotes:[{turnId:t.id,text:t.text}]}])};
  }else if(req.purpose==='condition-compile'){
   const t=input.turns.at(-1);
   value={when:availabilityBug?{op:'cmp',fact:'user.availability',rel:'ne',value:'busy'}:{op:'cmp',fact:'task:A.result.present',rel:'eq',value:true},quotes:[{turnId:t.turnId,start:0,end:t.text.length}],unsupported:unsupported?['unrepresentable']:[]};
  }else value={kind:'none',reasonCode:'no_current_action',question:null,optionIds:[]};
  return {ok:true,response:{protocol:'pet-capability-model/v1',requestId:req.requestId,sessionId:'fixture',model:{provider:'fixture',name:'fixture',version:'1'},rawText:JSON.stringify(value),startedAt:NOW,finishedAt:NOW,usage:{prompt_tokens:1,completion_tokens:1}}};
 }};return client;
}
async function run({availabilityBug=false,unsupported=false,retracted=false}={}){
 const db=new DatabaseSync(':memory:');const client=fixture({availabilityBug,unsupported});const handle=createConditionsHandle({},fetch,client,{fallbackToModel:false});handle.attach(db);
 const text=availabilityBug?'我现在很忙，等我不忙再问我；下一份结果预计2026-11-16T18:00:00.000Z':'结果回来再问我';
 handle.appendTurn({turnId:'u-A',sessionId:'s1',at:'2026-11-16T01:00:00.000Z',role:'user',text,taskIds:[TASK]});
 const first=await handle.assessor.assess(snapshot(),undefined,new AbortController().signal);
 const firstCalls=[...client.purposes];
 let second;
 if(!availabilityBug){
  const next=snapshot();
  if(retracted){new CapabilityMemoryStore(db).retractTurn('u-A','2026-11-16T01:30:00.000Z','user withdrew condition');next.task.result.revision=2;next.task.result.resultFileSha=sha('r2');}
  else if(!unsupported)handle.appendTurn({turnId:'u-B',sessionId:'s2',at:'2026-11-16T01:30:00.000Z',role:'user',text:'B任务的标题改成周报',taskIds:['B']});
  second=await handle.assessor.assess(next,undefined,new AbortController().signal);
 }
 const result={firstDraft:first.drafts[0],secondDraft:second?.drafts[0],firstCalls,allCalls:client.purposes,summary:handle.conditionSummary(TASK),memory:first.raw?.meta?.memoryPacket,eval:first.raw?.meta?.evaluation};
 await handle.close();db.close();return result;
}
const packet={preferences:[],currentFacts:[]};
const ctx=makeContext({ticketId:'A'},packet,{taskId:'A',declaredTasks:['A','B'],result:{runId:'rA',revision:1,status:'succeeded',metrics:{total:1,passed:1,failed:0},resultFileSha:sha('rA'),artifactSha:sha('aA'),observedAt:NOW}},NOW);
const multi={registered:ctx.allowedFacts,actual:Object.keys(ctx.facts),evaluation:evaluate({op:'all',args:['A','B'].map(t=>({op:'cmp',fact:`task:${t}.result.present`,rel:'eq',value:true}))},ctx)};
const report={unrelatedTask:await run(),wrongAvailability:await run({availabilityBug:true}),unsupportedRetry:await run({unsupported:true}),retractedSource:await run({retracted:true}),multi};
writeFileSync(new URL('./runtime-probes.json',import.meta.url),JSON.stringify(report,null,2));
console.log(JSON.stringify({unrelatedTask:{first:report.unrelatedTask.firstDraft.intent,second:report.unrelatedTask.secondDraft.intent,calls:report.unrelatedTask.allCalls},wrongAvailability:{intent:report.wrongAvailability.firstDraft.intent,reads:report.wrongAvailability.eval?.reads},unsupportedRetry:{calls:report.unsupportedRetry.allCalls},retractedSource:{second:report.retractedSource.secondDraft.intent,reason:report.retractedSource.secondDraft.reasonText,calls:report.retractedSource.allCalls},multi:{state:multi.evaluation.state,missing:multi.evaluation.reads.filter(x=>x.state==='unknown')}},null,2));
