import {readFileSync, readdirSync, writeFileSync} from 'node:fs';
import {dirname, join} from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
const root=dirname(fileURLToPath(import.meta.url));
const harness=await import(pathToFileURL(join(root,'source/pet-next/experiments/task-followup/eval/condition-followup/harness.mjs')));
const storyDir=join(root,'delivery/evidence/condition-followup/stories');
const stories=readdirSync(storyDir).filter(f=>f.endsWith('.json')).map(f=>JSON.parse(readFileSync(join(storyDir,f),'utf8')));
const rows=stories.map(s=>{
 const turns=s.sessions.flatMap(x=>x.turns);
 const correction=turns.find(t=>t.turnId.endsWith('-s4-t2'));
 const retraction=turns.find(t=>t.turnId.endsWith('-s6-t3'));
 const atStart=harness.readMemory(s,'version',0);
 const w=s.expectation.requiredDecisionWindows[0];
 return {id:s.id,turns:turns.length,uniqueTexts:new Set(turns.map(t=>t.text)).size,
  correction:{role:correction.role,text:correction.text,visible:atStart.turns.some(t=>t.turnId===correction.turnId)},
  retraction:{role:retraction.role,text:retraction.text,visibleAtEvent0:atStart.turns.some(t=>t.turnId===retraction.turnId)},
  readMemoryIgnoresIndex:JSON.stringify(atStart)===JSON.stringify(harness.readMemory(s,'version',s.events.length-1)),
  parsedCommitment:harness.readCommitment(atStart),expectedAfter:w.afterEvent,
  askAfterAllEventsScore:harness.scoreRun({decisions:[{index:999,action:'ask'}],reminders:1},s)};
});
const normalizedFamily=(s)=>s.sessions.flatMap(x=>x.turns).filter(t=>/-s0-t1$|-s4-t2$/.test(t.turnId)||(s.family==='retract-correct'&&/-s6-t3$/.test(t.turnId))).map(t=>({role:t.role,text:t.text}));
const familyPairs=[...new Set(stories.map(s=>s.family))].map(f=>({family:f,semanticInputsIdentical:JSON.stringify(normalizedFamily(stories.find(s=>s.family===f&&s.split==='dev')))===JSON.stringify(normalizedFamily(stories.find(s=>s.family===f&&s.split==='verify')))}));
const result={sourceHead:'2062807687b912a9ed65958d95c3e62b05b957ad',modelCalls:0,rows,familyPairs};
writeFileSync(join(root,'eval-independent-probe.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({stories:rows.length,uniqueTextCounts:rows.map(r=>r.uniqueTexts),correctionsWithAssistantRole:rows.filter(r=>r.correction.role==='assistant').length,ignoredTimeIndex:rows.filter(r=>r.readMemoryIgnoresIndex).length,futureRetractionAtEvent0:rows.filter(r=>r.id.startsWith('retract-')&&r.retraction.visibleAtEvent0).length,afterEndAskMarkedOk:rows.filter(r=>r.askAfterAllEventsScore.status==='ok').length,familyPairs},null,2));
