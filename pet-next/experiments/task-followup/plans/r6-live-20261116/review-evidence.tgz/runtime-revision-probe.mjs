import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { buildRuntime } from './source/pet-next/experiments/task-followup/runtime/build.ts';
import { seedResult } from './source/pet-next/experiments/task-followup/tools/seed.ts';
import { readResultFile } from './source/pet-next/experiments/task-followup/tools/watch.ts';
import { ANALYSIS_GOAL } from './source/pet-next/experiments/task-followup/tests/helpers.ts';
const root=resolve('runtime-revision-work-'+Date.now());mkdirSync(root,{recursive:true});
const snapshots=[];
const assessor={id:'review-snapshot-capture',capability:false,async assess(snapshot){snapshots.push(snapshot);return {drafts:[{intent:'none',reasonCode:'review_capture',reasonText:'Read-only snapshot capture'}],raw:{provider:'review',model:'fixture',rawOutput:''}};}};
const b=buildRuntime({workspaceRoot:root,policy:'P3',assessment:{assessor,timeoutMs:5000}});
const d=b.runtime.delegate({title:'review revision',goal:'分析当前测试结果',goalCondition:ANALYSIS_GOAL});
const records=[];
for(const revision of [1,2,3]){
 const r=seedResult({workspace:root,experimentId:'REVIEW',runId:'runA',revision,status:'partial',total:40,passed:30,failed:10});
 const finding=readResultFile({root,path:r.resultPath,observedAt:b.clock.now()});
 if(!finding.observed)throw Error(finding.detail);
 b.runtime.observe({ticketId:d.ticketId,observed:finding.observed});
 await new Promise(r=>setTimeout(r,20));await b.runtime.settleAssessments();
 const task=b.runtime.getTask(d.ticketId);const latest=snapshots.at(-1);
 records.push({resultRevision:task.result?.revision,taskRevision:task.taskRevision,snapshotTaskRevision:latest?.task.taskRevision,snapshotResultRevision:latest?.task.result?.revision,eventCursor:task.eventCursor});
}
await b.runtime.settleAssessments();b.db.close();
const result={head:'2062807',clock:'RealClock',workspace:root,records,stableTaskRevision:records.every(x=>x.taskRevision===1&&x.snapshotTaskRevision===1)};
writeFileSync('runtime-revision-probe.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
