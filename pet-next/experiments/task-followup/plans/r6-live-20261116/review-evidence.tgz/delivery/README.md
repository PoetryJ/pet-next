# R6 条件承诺 · 交付索引

基线 `964e03ed621dd1f9965b8e33e0e8c56185b3b70d`，集成分支 `codex/pet-conditions-r6`（HEAD `2062807`）。
未合并 main，未改产品默认；新模式只有显式 `--assessor capability-conditions` 才启用。

| 文件 | 内容 |
| --- | --- |
| `REPORT.json` | 按任务包模板填写的结构化回报（含逐轨 60 run、成本台账、未证明项） |
| `REPORT.md` | 一页正文（≤800 字） |
| `VERIFICATION.json` | 本轮核验：内核 SHA、151/67/typecheck、导入与失败链 |
| `logs/` | 原始日志：改动前基线 138、最终 151、能力 67、typecheck、两来源演示 |
| `evidence/two-source/` | 真实 JUnit 报告 + invocation + 导入结果（主测试 / 中文空格路径） |
| `evidence/injected-demo/` | 受控失败 r1 → 修复 r2 的原始 XML/invocation/result |
| `evidence/condition-followup/` | 12 故事 + 60 份逐 run JSON + summary.json（evaluator-only 判据） |
| `commits/commits.txt` | 基线到 HEAD 的提交清单 |
| `r6-conditions-incremental-2062807.bundle` | 增量 bundle（需先有 964e03e） |

## 复跑

```bash
git clone https://github.com/PoetryJ/pet-next && cd pet-next && git checkout 964e03e
git bundle unbundle ../r6-conditions-incremental-2062807.bundle   # 或 git fetch <bundle> codex/pet-conditions-r6
cd pet-next/experiments/task-followup
(cd tooling && npm install) && (cd producer/test-report/tooling && npm install)
env -u NODE_OPTIONS node run.mjs test                                    # 151/151
node --experimental-transform-types --no-warnings --test capability/tests/*.test.ts   # 67/67
env -u NODE_OPTIONS node run.mjs typecheck                               # 0
node --experimental-transform-types --no-warnings producer/test-report/two-source-demo.mjs --out producer/test-report/out
node eval/condition-followup/run.mjs --out out/condition-followup --regenerate
```

`env -u NODE_OPTIONS` 只用于绕开本机注入的 safe-delete shim（它把 `rmSync` 改成 trash，`/data3/.Trash-1003` 无写权限）；
在普通机器上可直接 `node run.mjs test`。

## 仍未运行

真实 72 跑五臂（无 `PET_MODEL_BASE_URL`）与 Windows 点击验收（无桌面），见 `REPORT.json` 的 `unproven`。
