import {mkdirSync,readFileSync,writeFileSync,existsSync} from 'node:fs';
import {join,resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';

const SCRIPT_DIR=dirname(fileURLToPath(import.meta.url));
const outIndex=process.argv.indexOf('--out');
const OUT=outIndex<0?SCRIPT_DIR:resolve(process.argv[outIndex+1]);
if(existsSync(join(OUT,'summary.json'))||existsSync(join(OUT,'environment.json')))throw Error('Existing evidence: choose a fresh --out directory; no model calls made.');
mkdirSync(OUT,{recursive:true});
const SOURCE=resolve(SCRIPT_DIR,'../../source');
const ROOT=join(SOURCE,'pet-next/experiments/task-followup');
const load=rel=>import(pathToFileURL(join(ROOT,rel)).href);
const sha=x=>createHash('sha256').update(typeof x==='string'?x:JSON.stringify(x)).digest('hex');
const save=(name,data)=>writeFileSync(join(OUT,name),JSON.stringify(data,null,2)+'\n','utf8');
const {createConditionCompiler,compilerSha256}=await load('capability/conditions/compiler.ts');
const {defaultFactDeclarations,bindingRegistrySha256}=await load('capability/conditions/plan-types.ts');
const {makeContext}=await load('capability/conditions/context.ts');
const {evaluate}=await load('capability/conditions/kernel.ts');
const {OpenAICompatibleClient}=await load('capability/model/openai-compatible.ts');
const startedAt=new Date().toISOString();
const health=await fetch('http://127.0.0.1:18882/health',{signal:AbortSignal.timeout(5000)}).then(r=>r.json());
if(!health.ready||health.model!=='Qwen3-8B')throw Error('unexpected model health');
const sourceFiles=['capability/conditions/compiler.ts','capability/conditions/context.ts','capability/conditions/kernel.ts','capability/conditions/plan-types.ts','capability/model/openai-compatible.ts'];
const sourceHead=execFileSync('git',['-C',SOURCE,'rev-parse','HEAD'],{encoding:'utf8'}).trim();
save('environment.json',{startedAt,node:process.version,platform:process.platform,sourceHead,health,sourceFiles:sourceFiles.map(path=>({path,sha256:sha(readFileSync(join(ROOT,path)).toString('utf8'))})),scope:'Two developer compiler diagnostics; no H2, long-memory or host integration claim.',budget:{postCap:4,completionCap:8192,maxTokensEach:2048},seed:0});
let actualPosts=0,reserved=0;
const fetchCounted=async(url,options)=>{
 if(options?.method==='POST'){
  const body=JSON.parse(options.body);const max=body.max_tokens;
  if(actualPosts>=4||!Number.isInteger(max)||reserved+max>8192)throw Error('local_budget_exhausted');
  actualPosts++;reserved+=max;
 }
 return fetch(url,options);
};
const client=new OpenAICompatibleClient({baseUrl:'http://127.0.0.1:18882/v1',apiKey:null,model:'Qwen3-8B',timeoutMs:240000,provider:'local-transformers',temperature:0,maxTokens:2048,disableThinking:true,recordDir:join(OUT,'model-io')},fetchCounted);
const compiler=createConditionCompiler();
const now=new Date().toISOString();
const initial='帮我跟进任务A的测试和任务B的中文路径检查。只有任务A和任务B的报告都到齐时，才问我是否继续；任何一份还没到就继续等待。';
const correction='更正刚才的安排：任务B不用等了。现在只等任务A的测试报告到达，再问我是否继续。';
const turn=(turnId,text)=>({turnId,role:'user',at:now,text,sha256:sha(text)});
const facts=defaultFactDeclarations(['A','B']);
const common={taskId:'A',allowedFacts:facts,bindingRegistrySha256:bindingRegistrySha256(facts,['A','B']),compilerSha256:compilerSha256({name:'Qwen3-8B',provider:'local-transformers',version:health.configSha256}),now};
const cases=[{id:'both-reports',input:{...common,commitmentRevision:1,userTurns:[turn('u1',initial)]}},{id:'corrected-only-A',input:{...common,commitmentRevision:2,userTurns:[turn('u1',initial),turn('u2',correction)]}}];
const packet={schema:'pet-capability-memory-packet/v1',taskId:'A',asOf:now,evaluatedAt:now,intent:'current',memoryCursor:1,currentFacts:[],preferences:[],commitments:[],outcomes:[],evidenceRefs:[],missing:[],conflicts:[],context:{nonActionable:[],recentTurns:[],slotResolution:[],budgetUsed:{items:0,chars:0},truncated:false,diagnostics:[]}};
const snapshot={ticketId:'A',title:'task A',goal:initial,taskRevision:1,assignmentId:null,stage:'running',status:'running',createdAt:now,updatedAt:now,eventCursor:1,memoryCursor:1,evidence:[],attempt:0};
const actualResult={runId:'diagnostic-A',revision:1,status:'succeeded',metrics:{total:10,passed:10,failed:0},resultFileSha:sha('developer fixture result A'),artifactSha:sha('developer fixture artifact A'),observedAt:now};
const contexts={
 neitherKnown:makeContext(snapshot,packet,{taskId:'A',declaredTasks:['A','B'],result:null},now),
 onlyA:makeContext(snapshot,packet,{taskId:'A',declaredTasks:['A','B'],result:actualResult},now),
 AConfirmedAbsent:makeContext(snapshot,packet,{taskId:'A',declaredTasks:['A','B'],result:null,scan:{at:now,listingSha256:sha('[]'),sourceId:'result:A'}},now)
};
save('context-fixtures.json',{scope:'Synthetic developer facts through unchanged production makeContext, not actual task reports.',contexts,bothReports:{status:'not_representable',reason:'VerifiedInputs exposes one result; makeContext fills only snapshot.ticketId. B is registered but cannot receive its own result.'}});
const outputs=[];
for(const c of cases){
 save(c.id+'.input.json',c.input);
 const start=Date.now();const result=await compiler.compile(c.input,client);const elapsedMs=Date.now()-start;
 const evaluations=result.status==='compiled'?Object.fromEntries(Object.entries(contexts).map(([name,ctx])=>[name,evaluate(result.plan.when,ctx)])):{};
 const independentExpected=c.id==='both-reports'?{neitherKnown:'unknown',onlyA:'unknown',AConfirmedAbsent:'false'}:{neitherKnown:'unknown',onlyA:'true',AConfirmedAbsent:'false'};
 const checks=Object.entries(independentExpected).map(([name,expected])=>({name,expected,actual:evaluations[name]?.state??null,pass:evaluations[name]?.state===expected}));
 const row={id:c.id,elapsedMs,result,evaluations,independentExpected,checks};outputs.push(row);save(c.id+'.result.json',row);
 console.log(JSON.stringify({id:c.id,status:result.status,reason:result.reason,elapsedMs,usage:result.rawCall?.usage,checks}));
}
const usages=outputs.map(x=>x.result.rawCall?.usage);
const summary={startedAt,finishedAt:new Date().toISOString(),sourceHead,actualPosts,httpSuccess:usages.filter(x=>x&&Number.isInteger(x.completion_tokens)).length,compileSuccess:outputs.filter(x=>x.result.status==='compiled').length,completionTokens:usages.reduce((n,x)=>n+(x?.completion_tokens??0),0),promptTokens:usages.reduce((n,x)=>n+(x?.prompt_tokens??0),0),unknownUsage:usages.filter(x=>!x).length,elapsedMs:outputs.reduce((n,x)=>n+x.elapsedMs,0),reservedMaxTokens:reserved,cases:outputs.map(x=>({id:x.id,status:x.result.status,reason:x.result.reason,elapsedMs:x.elapsedMs,checks:x.checks})),bothReportContext:'NOT_IMPLEMENTED: single result interface, current task only',scope:'Developer compiler pilot only; no host integration, actual reports, long-memory or H2 evidence.'};
save('summary.json',summary);console.log(JSON.stringify(summary));
