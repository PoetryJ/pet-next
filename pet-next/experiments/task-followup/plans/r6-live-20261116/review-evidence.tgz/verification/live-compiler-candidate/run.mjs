import {mkdirSync,readFileSync,writeFileSync,existsSync} from 'node:fs';
import {join,resolve,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const HERE=dirname(fileURLToPath(import.meta.url));
const outIndex=process.argv.indexOf('--out');
const OUT=outIndex<0?HERE:resolve(process.argv[outIndex+1]);
if(existsSync(join(OUT,'environment.json')))throw Error('Existing evidence; choose fresh --out before any model call.');
mkdirSync(OUT,{recursive:true});
const SOURCE=resolve(HERE,'../../source'), ROOT=join(SOURCE,'pet-next/experiments/task-followup');
const load=rel=>import(pathToFileURL(join(ROOT,rel)).href);
const sha=x=>createHash('sha256').update(typeof x==='string'?x:JSON.stringify(x)).digest('hex');
const save=(name,data)=>writeFileSync(join(OUT,name),JSON.stringify(data,null,2)+'\n','utf8');
const {createConditionCompiler,compilerSha256}=await load('capability/conditions/compiler.ts');
const {defaultFactDeclarations,bindingRegistrySha256}=await load('capability/conditions/plan-types.ts');
const {evaluate}=await load('capability/conditions/kernel.ts');
const {OpenAICompatibleClient}=await load('capability/model/openai-compatible.ts');
const candidate=readFileSync(join(HERE,'candidate-system.txt'),'utf8');
const candidateSha256=sha(candidate), sourceHead=execFileSync('git',['-C',SOURCE,'rev-parse','HEAD'],{encoding:'utf8'}).trim();
const health=await fetch('http://127.0.0.1:18882/health',{signal:AbortSignal.timeout(5000)}).then(r=>r.json());
if(!health.ready||health.model!=='Qwen3-8B')throw Error('unexpected model health');
const startedAt=new Date().toISOString(), now=startedAt;
save('environment.json',{startedAt,node:process.version,platform:process.platform,sourceHead,health,candidateSha256,budget:{maxPosts:6,maxCompletionTokens:8192,maxTokensEach:1024},scope:'Development prompt candidate; unchanged compiler/parser, real local Qwen, isolated synthetic truth table only; no production multi-source or H2 claim.'});
let actualPosts=0,reserved=0;
const fetchCounted=async(url,options)=>{if(options?.method==='POST'){const b=JSON.parse(options.body);if(actualPosts>=6||reserved+b.max_tokens>8192)throw Error('budget_exhausted');actualPosts++;reserved+=b.max_tokens;}return fetch(url,options);};
const realClient=new OpenAICompatibleClient({baseUrl:'http://127.0.0.1:18882/v1',apiKey:null,model:'Qwen3-8B',provider:'local-transformers',temperature:0,disableThinking:true,maxTokens:1024,timeoutMs:240000,recordDir:join(OUT,'model-io')},fetchCounted);
let currentCase;
const client={kind:realClient.kind,async complete(request,signal){
 const user=JSON.parse(request.messages.find(m=>m.role==='user').content), last=user.turns.at(-1);
 const tail=candidate.replaceAll('{{PRIMARY_PRESENT}}',`task:${user.taskId}.result.present`).replaceAll('{{LAST_TURN_ID}}',last.turnId).replaceAll('{{LAST_TURN_LENGTH}}',String(last.text.length)).replaceAll('{{TURN_LENGTHS}}',JSON.stringify(user.turns.map(t=>({turnId:t.turnId,utf16Length:t.text.length}))));
 const modified={...request,messages:request.messages.map(m=>m.role==='system'?{...m,content:m.content+'\n\n'+tail}:m)};
 save(currentCase+'.requests.json',{original:request,candidate:modified,candidateSha256});
 return realClient.complete(modified,signal);
}};
const initial='帮我跟进任务A的测试和任务B的中文路径检查。只有任务A和任务B的报告都到齐时，才问我是否继续；任何一份还没到就继续等待。';
const correction='更正刚才的安排：任务B不用等了。现在只等任务A的测试报告到达，再问我是否继续。';
const specs=[
 {id:'01-original-both',turns:[initial],target:'both'},
 {id:'02-original-correction-A',turns:[initial,correction],target:'A'},
 {id:'03-B-archive-only',turns:[initial,'调整一下：B的报告仅供归档，不再影响是否来问我。A报告到了就可以找我确认；B以后到没到、成功还是失败都不用等。'],target:'A'},
 {id:'04-only-B',turns:[initial,'这次别等A了，我只关心B的中文路径检查。B报告一到就问我是否继续，A有没有结果都不影响。'],target:'B'},
 {id:'05-restore-both',turns:[initial,correction,'恢复最初安排：重新把B也算进等待条件。只有A测试报告和B中文路径报告都到齐，才向我确认；缺任意一份就等。'],target:'both'},
 {id:'06-add-B-back',turns:['先约定只等A的测试报告。','现在多等一份B报告。A和B两份报告都必须回来才问我；报告里即使有失败项也算已经回来，不要要求测试全部通过。'],target:'both'},
];
const facts=defaultFactDeclarations(['A','B']);
const truthTable=[];
for(const A of ['unknown','false','true'])for(const B of ['unknown','false','true']){
 const context={now,allowedFacts:facts.map(f=>f.id),facts:{},currentBindings:{}};
 for(const [id,state] of Object.entries({A,B})){
  if(state==='unknown')continue;
  const binding={sourceId:`result:${id}`,version:'1',sha256:sha(`synthetic:${id}:${state}`)};context.currentBindings[binding.sourceId]=binding;
  const values=state==='false'?{'result.present':false}:{'result.present':true,'result.total':10,'result.passed':9,'result.failed':1,'result.revision':1,'result.status':'failed'};
  for(const [field,value] of Object.entries(values))context.facts[`task:${id}.${field}`]={value,binding,observedAt:now};
 }
 truthTable.push({A,B,context});
}
save('isolated-contexts.json',{scope:'isolated_semantic_test: synthetic verified facts passed to production kernel; not makeContext or host support.',truthTable});
save('frozen-cases.json',specs);
const compiler=createConditionCompiler(), rows=[];
for(const spec of specs){
 currentCase=spec.id;
 const turns=spec.turns.map((text,i)=>({turnId:`u${i+1}`,role:'user',at:new Date(Date.parse(now)+i).toISOString(),text,sha256:sha(text)}));
 const input={taskId:'A',commitmentRevision:turns.length,userTurns:turns,allowedFacts:facts,bindingRegistrySha256:bindingRegistrySha256(facts,['A','B']),compilerSha256:sha({base:compilerSha256({name:'Qwen3-8B',provider:'local-transformers',version:health.configSha256}),candidateSha256}),now};
 save(spec.id+'.input.json',input);
 const start=Date.now(), result=await compiler.compile(input,client), elapsedMs=Date.now()-start;
 const checks=truthTable.map(({A,B,context})=>{
  const expected=spec.target==='A'?A:spec.target==='B'?B:(A==='false'||B==='false')?'false':(A==='unknown'||B==='unknown')?'unknown':'true';
  const evaluation=result.status==='compiled'?evaluate(result.plan.when,context):null;
  return {A,B,expected,actual:evaluation?.state??null,pass:evaluation?.state===expected,evaluation};
 });
 const last=turns.at(-1), quotes=result.status==='compiled'?result.plan.sourceQuotes:[];
 const lastWholeTurnQuoted=quotes.some(q=>q.turnId===last.turnId&&q.start===0&&q.end===last.text.length&&q.text===last.text);
 const row={id:spec.id,target:spec.target,elapsedMs,result,lastWholeTurnQuoted,checks,scope:'isolated_semantic_test'};
 rows.push(row);save(spec.id+'.result.json',row);
 console.log(JSON.stringify({id:row.id,status:result.status,reason:result.reason,elapsedMs,usage:result.rawCall?.usage,passed:checks.filter(x=>x.pass).length,total:checks.length,lastWholeTurnQuoted}));
}
const usages=rows.map(r=>r.result.rawCall?.usage);
const summary={startedAt,finishedAt:new Date().toISOString(),sourceHead,candidateSha256,actualPosts,httpSuccess:usages.filter(u=>u&&Number.isInteger(u.completion_tokens)).length,compileSuccess:rows.filter(r=>r.result.status==='compiled').length,completionTokens:usages.reduce((n,u)=>n+(u?.completion_tokens??0),0),promptTokens:usages.reduce((n,u)=>n+(u?.prompt_tokens??0),0),unknownUsage:usages.filter(u=>!u).length,elapsedMs:rows.reduce((n,r)=>n+r.elapsedMs,0),checks:{total:54,passed:rows.flatMap(r=>r.checks).filter(c=>c.pass).length},wholeLatestQuote:rows.filter(r=>r.lastWholeTurnQuoted).length,cases:rows.map(r=>({id:r.id,status:r.result.status,reason:r.result.reason,elapsedMs:r.elapsedMs,passed:r.checks.filter(c=>c.pass).length,total:r.checks.length,lastWholeTurnQuoted:r.lastWholeTurnQuoted})),scope:'Single frozen prompt candidate, six developer cases, no retries. Synthetic kernel contexts do not close production multi-source gap or prove H2/long-memory.'};
save('summary.json',summary);console.log(JSON.stringify(summary));
